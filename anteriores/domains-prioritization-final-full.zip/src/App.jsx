
import React from 'react'
import DominiosTreeApp from './DominiosTreeApp.jsx'

export default function App() {
  return <DominiosTreeApp />
}
