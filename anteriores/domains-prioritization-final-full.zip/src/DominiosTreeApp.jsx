
import React, { useMemo, useState } from 'react'

// ---------- DATA MODEL ----------
const GERENCIAS = [
  { id: 'GEST', label: 'Gerencia de Estrategia y Transformación' },
  { id: 'GINS', label: 'Gerencia UN Insumos' },
  { id: 'GCAB', label: 'Gerencia CAB' },
  { id: 'GCER', label: 'Gerencia UN Cereales' },
  { id: 'GADM', label: 'Gerencia Administrativa' },
  { id: 'GBEB', label: 'Gerencia UN Bebidas' },
]

// Dominios clave
const DOMINIOS_BASE = [
  { id: 'dom-gob', gerenciaId: 'GEST', label: 'Gobierno del Dato / Infraestructura', madurez: 2.1, riesgo: 5, depTI: 5, transversalidad: 5 },
  { id: 'dom-fin-cxp', gerenciaId: 'GEST', label: 'Finanzas – Cuentas por Pagar', madurez: 2.4, riesgo: 3, depTI: 4, transversalidad: 3 },
  { id: 'dom-comp-aud', gerenciaId: 'GADM', label: 'Cumplimiento & Auditoría', madurez: 3.2, riesgo: 3, depTI: 2, transversalidad: 2 },
  { id: 'dom-jur-contr', gerenciaId: 'GADM', label: 'Jurídico – Contratos', madurez: 3.1, riesgo: 2, depTI: 2, transversalidad: 3 },
  { id: 'dom-agro', gerenciaId: 'GINS', label: 'Agroinsumos & ERP Agrícola', madurez: 1.9, riesgo: 4, depTI: 4, transversalidad: 4 },
  { id: 'dom-arroz', gerenciaId: 'GCER', label: 'Producción Arroz & Paddy', madurez: 2.0, riesgo: 4, depTI: 3, transversalidad: 3 },
  { id: 'dom-exc-com', gerenciaId: 'GBEB', label: 'Excelencia Comercial Bebidas', madurez: 2.3, riesgo: 4, depTI: 4, transversalidad: 3 },
  { id: 'dom-supply', gerenciaId: 'GCAB', label: 'Supply Chain / S&OP / Precios', madurez: 1.9, riesgo: 5, depTI: 5, transversalidad: 5 },
]

// Procesos por dominio
const PROCESOS = {
  'dom-gob': ['Comité y roles de gobierno', 'Arquitectura y plataforma', 'Políticas y estándares'],
  'dom-fin-cxp': ['Registro de facturas', 'Aprobación y programación de pagos', 'Conciliaciones'],
  'dom-comp-aud': ['Planeación de auditorías', 'Ejecución y hallazgos', 'Planes de acción'],
  'dom-jur-contr': ['Solicitud de contrato', 'Revisión jurídica', 'Renovación / terminación'],
  'dom-agro': ['Compras de agroinsumos', 'Gestión de inventarios', 'Seguimiento a visitas de campo'],
  'dom-arroz': ['Compra de paddy', 'Clasificación por calidad', 'Liquidación a agricultores'],
  'dom-exc-com': ['Monitoreo de ventas', 'Gestión de KPIs SICOE/SIESA', 'Seguimiento a ejecución comercial'],
  'dom-supply': ['Planeación de demanda', 'Ciclo S&OP mensual', 'Optimización de compras indirectas'],
}

// Iniciativas Siembra
const INICIATIVAS = [
  { id: 'init-gob', dominioId: 'dom-gob', nombre: 'Estrategia Gobierno de Datos e Infraestructura', ola: 'OLA 1 y 2', descripcion: 'Marco de gobierno, arquitectura y despliegue de infraestructura para datos.' },
  { id: 'init-cxp', dominioId: 'dom-fin-cxp', nombre: 'Modelo Analítico Cuentas por Pagar', ola: 'OLA 1', descripcion: 'Modelo para revisar tiempos de pago y eficiencia del proceso P2P.' },
  { id: 'init-comp-aud', dominioId: 'dom-comp-aud', nombre: 'Herramienta Compliance y Auditoría', ola: 'OLA 1', descripcion: 'Gestión de políticas, planes y seguimiento de cumplimiento.' },
  { id: 'init-contr', dominioId: 'dom-jur-contr', nombre: 'Herramienta Gestión de Contratos', ola: 'OLA 1', descripcion: 'Automatizar solicitud, revisión y ciclo de vida de contratos.' },
  { id: 'init-agro-analitico', dominioId: 'dom-agro', nombre: 'Modelo analítico compras agroquímicos y fertilizantes', ola: 'OLA 1 y 2', descripcion: 'Tableros para compras, inventarios, zona/subzona y vendedor.' },
  { id: 'init-kuna', dominioId: 'dom-agro', nombre: 'Herramienta KUNA', ola: 'OLA 1 y 2', descripcion: 'Toma de pedidos y control de inventarios de agroquímicos.' },
  { id: 'init-erp-agri', dominioId: 'dom-agro', nombre: 'Definición e implementación ERP agrícola', ola: 'OLA 2', descripcion: 'ERP especializado para negocio agrícola.' },
  { id: 'init-casanare', dominioId: 'dom-agro', nombre: 'Centro de formación Casanare', ola: 'OLA 2', descripcion: 'Uso de datos para segmentar y conocer mejor a agricultores.' },
  { id: 'init-arroz-local', dominioId: 'dom-arroz', nombre: 'Gestión de arroz de local', ola: 'OLA 1', descripcion: 'Analítica de compras de paddy según variables de calidad.' },
  { id: 'init-exc-com', dominioId: 'dom-exc-com', nombre: 'Excelencia Comercial – UN Bebidas', ola: 'OLA 1 y 2', descripcion: 'Integración SICOE + SIESA para centralizar datos comerciales.' },
  { id: 'init-sop', dominioId: 'dom-supply', nombre: 'S&OP', ola: 'OLA 2', descripcion: 'Herramienta colaborativa para forecast y planificación de demanda.' },
  { id: 'init-precios', dominioId: 'dom-supply', nombre: 'Analítica de Datos / Precios', ola: 'OLA 2', descripcion: 'Análisis de precios de materiales indirectos.' },
  { id: 'init-bots', dominioId: 'dom-supply', nombre: 'Bots de gestión (Referenciación, Servicios, Facturación)', ola: 'OLA 2', descripcion: 'Automatización de procesos con integración a ERP / TMS.' },
]

// Layout del grafo
const GRAPH_LAYOUT = {
  'dom-gob': { x: 260, y: 135 },
  'dom-supply': { x: 440, y: 70 },
  'dom-agro': { x: 440, y: 210 },
  'dom-arroz': { x: 90, y: 70 },
  'dom-exc-com': { x: 90, y: 210 },
  'dom-fin-cxp': { x: 260, y: 25 },
  'dom-comp-aud': { x: 260, y: 245 },
  'dom-jur-contr': { x: 90, y: 140 },
}

// Enlaces entre dominios
const GRAPH_EDGES = [
  ...DOMINIOS_BASE.filter(d => d.id !== 'dom-gob').map(d => ({ from: 'dom-gob', to: d.id, type: 'core' })),
]

GERENCIAS.forEach(g => {
  const ds = DOMINIOS_BASE.filter(d => d.gerenciaId === g.id)
  if (ds.length > 1) {
    for (let i = 0; i < ds.length - 1; i++) {
      GRAPH_EDGES.push({ from: ds[i].id, to: ds[i + 1].id, type: 'gerencia' })
    }
  }
})

// Helpers
function prioridadColor(score) {
  if (score >= 80) return 'bg-red-100 text-red-700 border-red-300'
  if (score >= 60) return 'bg-amber-100 text-amber-700 border-amber-300'
  if (score >= 40) return 'bg-yellow-100 text-yellow-700 border-yellow-300'
  return 'bg-emerald-100 text-emerald-700 border-emerald-300'
}

function prioridadLabel(score) {
  if (score >= 80) return 'Crítica'
  if (score >= 60) return 'Alta'
  if (score >= 40) return 'Media'
  return 'Baja'
}

const NodePill = ({ label, score }) => (
  <div className={
    'inline-flex items-center gap-2 rounded-full px-3 py-1 border text-[11px] ' +
    prioridadColor(score)
  }>
    <span className="font-semibold">{label}</span>
    <span className="opacity-80">{score}</span>
  </div>
)

const getGerenciaLabel = gerenciaId => {
  const g = GERENCIAS.find(ge => ge.id === gerenciaId)
  return g ? g.label : ''
}

// ---------- COMPONENTE PRINCIPAL ----------
export default function DominiosTreeApp() {
  const [selectedDominioId, setSelectedDominioId] = useState('dom-gob')
  const [weights, setWeights] = useState({
    madurez: 4,
    riesgo: 5,
    depTI: 5,
    transversalidad: 4,
  })

  const computeScore = d => {
    const invMadurez = 6 - d.madurez
    const raw =
      invMadurez * weights.madurez +
      d.riesgo * weights.riesgo +
      d.depTI * weights.depTI +
      d.transversalidad * weights.transversalidad

    const maxRaw = 5 * (weights.madurez + weights.riesgo + weights.depTI + weights.transversalidad)
    return Math.round((raw / maxRaw) * 100)
  }

  const dominiosWithScore = useMemo(
    () =>
      DOMINIOS_BASE.map(d => ({
        ...d,
        score: computeScore(d),
      })).sort((a, b) => b.score - a.score),
    [weights],
  )

  const selectedDominio = useMemo(
    () => dominiosWithScore.find(d => d.id === selectedDominioId) ?? dominiosWithScore[0],
    [dominiosWithScore, selectedDominioId],
  )

  const iniciativasDominio = useMemo(
    () => INICIATIVAS.filter(i => i.dominioId === selectedDominio.id),
    [selectedDominio],
  )

  const treeByGerencia = useMemo(
    () =>
      GERENCIAS.map(g => ({
        ...g,
        dominios: dominiosWithScore.filter(d => d.gerenciaId === g.id),
      })).filter(g => g.dominios.length > 0),
    [dominiosWithScore],
  )

  const handleWeightChange = (key, value) => {
    setWeights(prev => ({ ...prev, [key]: Number(value) }))
  }

  const scoreMap = useMemo(() => {
    const map = {}
    dominiosWithScore.forEach(d => {
      map[d.id] = d.score
    })
    return map
  }, [dominiosWithScore])

  const satelliteNodes = useMemo(() => {
    const center = GRAPH_LAYOUT[selectedDominio.id]
    if (!center) return []

    const procesos = PROCESOS[selectedDominio.id] || []
    const iniciativas = INICIATIVAS.filter(i => i.dominioId === selectedDominio.id)
    const gerenciaLabel = getGerenciaLabel(selectedDominio.gerenciaId)

    const items = []
    if (gerenciaLabel) items.push({ type: 'gerencia', label: gerenciaLabel })
    iniciativas.forEach(init => items.push({ type: 'iniciativa', label: init.nombre, ola: init.ola }))
    procesos.forEach(proc => items.push({ type: 'proceso', label: proc }))

    const radius = 60
    const total = items.length || 1

    return items.map((item, idx) => {
      const angle = (2 * Math.PI * idx) / total
      return {
        ...item,
        x: center.x + radius * Math.cos(angle),
        y: center.y + radius * Math.sin(angle),
        cx: center.x,
        cy: center.y,
      }
    })
  }, [selectedDominio])

  return (
    <div className="min-h-screen bg-slate-50 p-6 md:p-10 text-slate-800">
      <div className="max-w-6xl mx-auto">
        {/* HEADER */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
              Mapa de Dominios Prioritarios – Árbol & Grafo Interactivo
            </h1>
            <p className="text-slate-600 text-sm mt-1 max-w-2xl">
              Visualización jerárquica (Gerencias → Dominios → Iniciativas Siembra) combinada con un
              grafo de nodos que muestra cómo se relacionan los dominios. Ajusta los pesos de
              madurez, riesgo, dependencia TI y transversalidad para ver cómo cambia la prioridad.
            </p>
          </div>
          <div className="text-xs text-slate-500 border rounded-xl px-3 py-2 bg-white shadow-sm">
            <div className="font-semibold mb-1">Leyenda de priorización</div>
            <div className="flex flex-wrap gap-2">
              <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 border border-red-300">
                80–100 Crítica
              </span>
              <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 border border-amber-300">
                60–79 Alta
              </span>
              <span className="px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-700 border border-yellow-300">
                40–59 Media
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 border border-emerald-300">
                0–39 Baja
              </span>
            </div>
          </div>
        </div>

        {/* LAYOUT PRINCIPAL */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Árbol */}
          <div className="lg:col-span-2 rounded-2xl bg-white border shadow-sm p-4 md:p-6 relative overflow-hidden">
            <h2 className="text-sm font-semibold mb-4">Árbol de gerencias, dominios e iniciativas</h2>
            <div className="space-y-4 relative">
              {treeByGerencia.map(ger => (
                <div key={ger.id} className="relative pl-4 border-l border-slate-200">
                  <div className="mb-2 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-slate-400" />
                    <div className="text-[13px] font-semibold text-slate-800">
                      {ger.label}
                    </div>
                  </div>
                  <div className="space-y-2 ml-4">
                    {ger.dominios.map(dom => {
                      const isSelected = dom.id === selectedDominio.id
                      return (
                        <div key={dom.id} className="relative pl-4">
                          <div className="absolute left-0 top-0 bottom-0 w-px bg-slate-200" />
                          <button
                            onClick={() => setSelectedDominioId(dom.id)}
                            className={
                              'w-full text-left rounded-xl px-3 py-2 border flex flex-col gap-1 bg-white hover:bg-slate-50 transition ' +
                              (isSelected ? 'border-sky-400 ring-1 ring-sky-200 shadow-sm' : 'border-slate-200')
                            }
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-[12px] font-medium text-slate-800">
                                {dom.label}
                              </span>
                              <NodePill label={prioridadLabel(dom.score)} score={dom.score} />
                            </div>
                            <div className="flex flex-wrap gap-2 mt-1 text-[11px] text-slate-500">
                              <span>Madurez: {dom.madurez.toFixed(1)}</span>
                              <span>Riesgo: {dom.riesgo}</span>
                              <span>Dep. TI: {dom.depTI}</span>
                              <span>Transversalidad: {dom.transversalidad}</span>
                            </div>
                            <div className="mt-2 pl-3 border-l border-dashed border-slate-200 space-y-1">
                              {INICIATIVAS.filter(i => i.dominioId === dom.id).map(init => (
                                <div
                                  key={init.id}
                                  className="flex items-center justify-between gap-2 text-[11px] text-slate-600"
                                >
                                  <div className="flex items-center gap-1">
                                    <div className="w-1.5 h-1.5 rounded-full bg-slate-300" />
                                    <span>{init.nombre}</span>
                                  </div>
                                  <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                                    {init.ola}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </button>
                        </div>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Panel detalle */}
          <div className="rounded-2xl bg-white border shadow-sm p-4 md:p-6 flex flex-col gap-4">
            <div>
              <h2 className="text-sm font-semibold mb-1">Detalle del dominio seleccionado</h2>
              <p className="text-[12px] text-slate-500">
                Haz clic en un dominio dentro del árbol para ver sus criterios de priorización y las
                iniciativas Siembra asociadas.
              </p>
            </div>
            <div className={
              'rounded-2xl border p-4 flex flex-col gap-2 ' +
              prioridadColor(selectedDominio.score)
            }>
              <div className="text-[11px] uppercase tracking-wide opacity-70">
                Dominio prioritario
              </div>
              <div className="flex items-center justify-between gap-2">
                <div className="text-[14px] font-semibold max-w-[70%]">
                  {selectedDominio.label}
                </div>
                <div className="text-right">
                  <div className="text-[11px] opacity-70">Score</div>
                  <div className="text-xl font-bold leading-none">
                    {selectedDominio.score}
                  </div>
                  <div className="text-[11px] opacity-80">
                    {prioridadLabel(selectedDominio.score)}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px] mt-2">
                <div className="rounded-xl bg-white/60 border border-white/80 px-2 py-1">
                  <div className="opacity-70">Madurez</div>
                  <div className="font-semibold text-[13px]">
                    {selectedDominio.madurez.toFixed(1)} / 5.0
                  </div>
                </div>
                <div className="rounded-xl bg-white/60 border border-white/80 px-2 py-1">
                  <div className="opacity-70">Riesgo Operativo</div>
                  <div className="font-semibold text-[13px]">
                    {selectedDominio.riesgo} / 5
                  </div>
                </div>
                <div className="rounded-xl bg-white/60 border border-white/80 px-2 py-1">
                  <div className="opacity-70">Dependencia TI</div>
                  <div className="font-semibold text-[13px]">
                    {selectedDominio.depTI} / 5
                  </div>
                </div>
                <div className="rounded-xl bg-white/60 border border-white/80 px-2 py-1">
                  <div className="opacity-70">Transversalidad</div>
                  <div className="font-semibold text-[13px]">
                    {selectedDominio.transversalidad} / 5
                  </div>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-[13px] font-semibold mb-2">Iniciativas Siembra asociadas</h3>
              <div className="space-y-2 max-h-60 overflow-auto pr-1">
                {iniciativasDominio.map(init => (
                  <div
                    key={init.id}
                    className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-[11px]"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-slate-800">
                        {init.nombre}
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                        {init.ola}
                      </span>
                    </div>
                    <p className="text-slate-600 text-[11px] leading-snug">
                      {init.descripcion}
                    </p>
                  </div>
                ))}
                {iniciativasDominio.length === 0 && (
                  <p className="text-[11px] text-slate-400">
                    Este dominio aún no tiene iniciativas Siembra asociadas en el modelo.
                  </p>
                )}
              </div>
            </div>
            <div className="mt-2 text-[11px] text-slate-500 border-t pt-3">
              Este panel puede reutilizarse en el dashboard ejecutivo para justificar por qué un
              dominio es prioritario y qué iniciativas lo están abordando.
            </div>
          </div>
        </div>

        {/* Simulador + Grafo */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="rounded-2xl bg-white border shadow-sm p-4 md:p-6 flex flex-col gap-4">
            <h2 className="text-sm font-semibold mb-1">Simulador de pesos de priorización</h2>
            <p className="text-[12px] text-slate-500 mb-2">
              Ajusta los pesos de cada criterio para ver cómo cambia el score y el color de cada nodo
              en el grafo. Útil para conversar con negocio sobre riesgo, urgencia e impacto.
            </p>
            {[
              { key: 'madurez', label: 'Madurez (invertida – menor madurez, más prioridad)' },
              { key: 'riesgo', label: 'Riesgo operativo' },
              { key: 'depTI', label: 'Dependencia de TI' },
              { key: 'transversalidad', label: 'Transversalidad (nº de gerencias impactadas)' },
            ].map(item => (
              <div key={item.key} className="text-[12px]">
                <div className="flex items-center justify_between mb-1">
                  <span className="font-medium text-slate-700">{item.label}</span>
                  <span className="text-slate-500">Peso: {weights[item.key]}</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={8}
                  value={weights[item.key]}
                  onChange={e => handleWeightChange(item.key, e.target.value)}
                  className="w-full"
                />
              </div>
            ))}
            <p className="mt-2 text-[11px] text-slate-500">
              El cálculo normaliza el resultado entre 0 y 100. Puedes usar este módulo en sesión para
              preguntar: “¿Qué pasa si le damos más peso al riesgo o a la transversalidad?” y ver
              cómo se reordenan los dominios.
            </p>
          </div>

          <div className="lg:col-span-2 rounded-2xl bg-white border shadow-sm p-4 md:p-6">
            <h2 className="text-sm font-semibold mb-1">Grafo de interacciones entre dominios</h2>
            <p className="text-[12px] text-slate-500 mb-3">
              Cada círculo grande representa un dominio; los enlaces muestran relaciones de gobierno
              y pertenencia a la misma gerencia. Los nodos satélite muestran la gerencia, las
              iniciativas Siembra y los procesos asociados al dominio seleccionado. El color y el
              borde reflejan el nivel de prioridad con los pesos actuales.
            </p>
            <div className="border rounded-2xl bg-slate-50 p-3 overflow-hidden">
              <svg viewBox="0 0 520 270" className="w-full h-[260px]">
                {GRAPH_EDGES.map((edge, idx) => {
                  const from = GRAPH_LAYOUT[edge.from]
                  const to = GRAPH_LAYOUT[edge.to]
                  if (!from || !to) return null
                  const stroke = edge.type === 'core' ? '#9ca3af' : '#cbd5f5'
                  const dash = edge.type === 'core' ? '0' : '4,4'
                  return (
                    <line
                      key={idx}
                      x1={from.x}
                      y1={from.y}
                      x2={to.x}
                      y2={to.y}
                      stroke={stroke}
                      strokeWidth={1}
                      strokeDasharray={dash}
                    />
                  )
                })}
                {satelliteNodes.map((node, idx) => {
                  const stroke =
                    node.type === 'gerencia'
                      ? '#0f766e'
                      : node.type === 'iniciativa'
                      ? '#0369a1'
                      : '#6b7280'
                  const fill =
                    node.type === 'gerencia'
                      ? '#a7f3d0'
                      : node.type === 'iniciativa'
                      ? '#bfdbfe'
                      : '#e5e7eb'
                  const r =
                    node.type === 'gerencia'
                      ? 12
                      : node.type === 'iniciativa'
                      ? 8
                      : 5
                  return (
                    <g key={idx}>
                      <line
                        x1={node.cx}
                        y1={node.cy}
                        x2={node.x}
                        y2={node.y}
                        stroke="#d1d5db"
                        strokeWidth={0.8}
                      />
                      <circle cx={node.x} cy={node.y} r={r} fill={fill} stroke={stroke} strokeWidth={1.2} />
                      <title>
                        {node.type.toUpperCase()}: {node.label}
                        {node.ola ? ` – ${node.ola}` : ''}
                      </title>
                    </g>
                  )
                })}
                {DOMINIOS_BASE.map(dom => {
                  const pos = GRAPH_LAYOUT[dom.id]
                  if (!pos) return null
                  const score = scoreMap[dom.id] ?? 0
                  const isSelected = dom.id === selectedDominio.id
                  let fill = '#6ee7b7'
                  if (score >= 80) fill = '#fecaca'
                  else if (score >= 60) fill = '#fed7aa'
                  else if (score >= 40) fill = '#fef3c7'
                  const stroke = isSelected ? '#0ea5e9' : '#374151'
                  return (
                    <g
                      key={dom.id}
                      transform={`translate(${pos.x},${pos.y})`}
                      style={{ cursor: 'pointer' }}
                      onClick={() => setSelectedDominioId(dom.id)}
                    >
                      <circle r={18} fill={fill} stroke={stroke} strokeWidth={isSelected ? 3 : 1.2} />
                      <title>
                        {dom.label}{'\n'}Score: {score} ({prioridadLabel(score)})
                      </title>
                      <text textAnchor="middle" y={-26} className="text-[10px] fill-slate-700">
                        {score}
                      </text>
                      <text textAnchor="middle" y={4} className="text-[9px] fill-slate-800">
                        {dom.label.split(' ')[0]}
                      </text>
                    </g>
                  )
                })}
              </svg>
            </div>
            <p className="mt-2 text-[11px] text-slate-500">
              Esta versión es suficiente para conversar en comité sobre cómo se entrelazan gerencias,
              dominios, procesos e iniciativas, y cómo cambia la prioridad al mover los pesos.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
