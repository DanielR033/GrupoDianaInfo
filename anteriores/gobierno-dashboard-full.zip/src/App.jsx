import React, { useMemo, useState } from 'react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  LineChart,
  Line,
} from 'recharts'
import {
  Info,
  Filter,
  Gauge,
  Shield,
  Settings,
  Layers,
  Database,
  TrendingUp,
  BookOpen,
  Users,
  BarChart3,
} from 'lucide-react'

// ------------------- DATA -------------------

// Gerencias (macro–áreas ejecutivas)
const AREAS = [
  { id: 'ALL',   label: 'General (Todas las gerencias)' },
  { id: 'GADM',  label: 'G. Administrativa' },
  { id: 'GEST',  label: 'G. Estrategia y Transformación' },
  { id: 'GINS',  label: 'G. UN Insumos' },
  { id: 'GCOM',  label: 'G. Comercial' },
  { id: 'GCER',  label: 'G. UN Cereales' },
  { id: 'GMKT',  label: 'G. Mercadeo' },
  { id: 'GBEB',  label: 'G. UN Bebidas' },
  { id: 'GGRAS', label: 'G. UN Grasas' },
  { id: 'GSAL',  label: 'G. UN Salsas' },
  { id: 'GCAB',  label: 'G. CAB' },
]

// Dimensiones DAMA agregadas
const DIMENSIONS = [
  { key: 'governance',   label: 'Gobierno' },
  { key: 'quality',      label: 'Calidad' },
  { key: 'metadata',     label: 'Metadatos' },
  { key: 'security',     label: 'Seguridad/Priv' },
  { key: 'architecture', label: 'Arquitectura' },
  { key: 'integration',  label: 'Integración/Analítica' },
]

// Madurez promedio por gerencia (1–5)
const SCORES = {
  ALL:  { governance: 2.1, quality: 2.1, metadata: 1.2, security: 3.0, architecture: 2.0, integration: 2.1 },
  GADM: { governance: 2.2, quality: 2.2, metadata: 1.2, security: 3.2, architecture: 2.2, integration: 2.2 },
  GEST: { governance: 2.5, quality: 2.6, metadata: 1.6, security: 3.4, architecture: 2.8, integration: 2.8 },
  GINS: { governance: 2.2, quality: 2.2, metadata: 1.2, security: 3.2, architecture: 2.2, integration: 2.2 },
  GCOM: { governance: 1.7, quality: 1.7, metadata: 1.0, security: 2.7, architecture: 1.7, integration: 2.0 },
  GCER: { governance: 2.5, quality: 2.5, metadata: 1.5, security: 3.0, architecture: 2.0, integration: 2.0 },
  GMKT: { governance: 2.0, quality: 2.0, metadata: 1.0, security: 3.0, architecture: 2.0, integration: 2.0 },
  GBEB: { governance: 2.0, quality: 2.0, metadata: 1.0, security: 3.0, architecture: 2.0, integration: 2.0 },
  GGRAS:{ governance: 2.0, quality: 2.0, metadata: 1.0, security: 3.0, architecture: 2.0, integration: 2.0 },
  GSAL: { governance: 2.0, quality: 2.0, metadata: 1.0, security: 2.5, architecture: 1.5, integration: 1.5 },
  GCAB: { governance: 2.0, quality: 2.0, metadata: 1.0, security: 2.7, architecture: 2.0, integration: 2.0 },
}

// Indicadores ejecutivos por gerencia
const INDICATORS = {
  ALL:  { coverage: 'Alta',  autonomy: 2.6, dependency: 3.6, itload: 3.4 },
  GADM: { coverage: 'Alta',  autonomy: 3.0, dependency: 3.5, itload: 3.2 },
  GEST: { coverage: 'Alta',  autonomy: 3.5, dependency: 4.5, itload: 4.5 },
  GINS: { coverage: 'Alta',  autonomy: 3.0, dependency: 3.8, itload: 3.5 },
  GCOM: { coverage: 'Alta',  autonomy: 2.0, dependency: 3.0, itload: 3.0 },
  GCER: { coverage: 'Alta',  autonomy: 2.5, dependency: 3.5, itload: 3.2 },
  GMKT: { coverage: 'Media', autonomy: 2.5, dependency: 3.0, itload: 2.8 },
  GBEB: { coverage: 'Media', autonomy: 2.0, dependency: 4.0, itload: 3.5 },
  GGRAS:{ coverage: 'Media', autonomy: 2.0, dependency: 4.0, itload: 3.5 },
  GSAL: { coverage: 'Media', autonomy: 2.0, dependency: 2.8, itload: 2.5 },
  GCAB: { coverage: 'Media', autonomy: 2.2, dependency: 3.5, itload: 3.2 },
}

// ------------------- HELPERS -------------------

function kpiColor(value, invert = false) {
  if (invert) value = 6 - value
  if (value >= 4.2) return 'bg-emerald-50 text-emerald-700 border-emerald-200'
  if (value >= 3.2) return 'bg-sky-50 text-sky-700 border-sky-200'
  if (value >= 2.2) return 'bg-amber-50 text-amber-700 border-amber-200'
  return 'bg-rose-50 text-rose-700 border-rose-200'
}

function coveragePill(level) {
  const base =
    'inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold'
  if (level === 'Alta')
    return <span className={base + ' bg-emerald-100 text-emerald-700'}>
      Cobertura Alta
    </span>
  if (level === 'Media')
    return <span className={base + ' bg-amber-100 text-amber-700'}>
      Cobertura Media
    </span>
  return <span className={base + ' bg-rose-100 text-rose-700'}>
    Cobertura Baja
  </span>
}

function heatColor(v) {
  if (v >= 4.2) return 'bg-emerald-100 text-emerald-700 border-emerald-200'
  if (v >= 3.2) return 'bg-sky-100 text-sky-800 border-sky-200'
  if (v >= 2.2) return 'bg-amber-100 text-amber-800 border-amber-200'
  return 'bg-rose-100 text-rose-800 border-rose-200'
}

const SectionTitle = ({ icon: Icon, title, subtitle }) => (
  <div className="flex items-start gap-2 mb-3">
    <div className="p-1.5 rounded-xl bg-slate-100">
      <Icon className="w-4 h-4 text-slate-700" />
    </div>
    <div>
      <h3 className="text-sm font-semibold tracking-tight">{title}</h3>
      {subtitle && (
        <p className="text-[12px] text-slate-500 leading-relaxed">
          {subtitle}
        </p>
      )}
    </div>
  </div>
)

// ------------------- COMPONENT -------------------

export default function App() {
  const [area, setArea] = useState('ALL')
  const score = SCORES[area]
  const ind = INDICATORS[area]

  // Radar
  const radarData = useMemo(
    () =>
      DIMENSIONS.map(d => ({
        dimension: d.label,
        valor: score[d.key],
      })),
    [score],
  )

  // Gaps vs objetivo 3.0
  const gapData = useMemo(
    () =>
      DIMENSIONS.map(d => ({
        name: d.label,
        Gap: Number((score[d.key] - 3.0).toFixed(2)),
      })),
    [score],
  )

  // Heatmap
  const heatmapData = useMemo(
    () =>
      AREAS.filter(a => a.id !== 'ALL').map(a => ({
        area: a.label,
        values: DIMENSIONS.map(d => ({
          key: d.label,
          value: SCORES[a.id][d.key],
        })),
      })),
    [],
  )

  const avg = useMemo(() => {
    const vals = Object.values(score)
    return (vals.reduce((a, b) => a + Number(b), 0) / vals.length).toFixed(1)
  }, [score])

  return (
    <div className="min-h-screen w-full bg-[#f6f7f9] p-6 md:p-10 text-slate-800">
      <div className="max-w-6xl mx-auto">
        {/* HEADER */}
        <div className="mb-6 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-[28px] font-semibold tracking-tight">
              Gobierno del Dato – Panel Ejecutivo
            </h1>
            <p className="text-slate-600 text-[14px] mt-1">
              Explora la madurez, brechas culturales y capacidades por
              gerencia y dimensión DAMA.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <select
              value={area}
              onChange={e => setArea(e.target.value)}
              className="w-[260px] rounded-xl border bg-white px-3 py-2 shadow-sm text-[14px]"
            >
              {AREAS.map(a => (
                <option key={a.id} value={a.id}>
                  {a.label}
                </option>
              ))}
            </select>
            <button className="inline-flex items-center gap-1.5 rounded-xl border px-3 py-2 bg-white shadow-sm text-[13px] text-slate-700">
              <Filter className="w-4 h-4" />
              Filtros
            </button>
          </div>
        </div>

        {/* KPI CARDS */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div
            className={
              'rounded-2xl border p-4 shadow-sm flex flex-col gap-1 ' +
              kpiColor(Number(avg))
            }
          >
            <span className="text-[12px] text-slate-600">
              Madurez Promedio
            </span>
            <span className="text-[24px] font-semibold flex items-center gap-1">
              {avg}
              <Gauge className="w-4 h-4" />
            </span>
          </div>
          <div
            className={
              'rounded-2xl border p-4 shadow-sm flex flex-col gap-1 ' +
              kpiColor(ind.autonomy)
            }
          >
            <span className="text-[12px] text-slate-600">
              Autonomía de la Gerencia
            </span>
            <span className="text-[24px] font-semibold flex items-center gap-1">
              {ind.autonomy.toFixed(1)}
              <Users className="w-4 h-4" />
            </span>
          </div>
          <div
            className={
              'rounded-2xl border p-4 shadow-sm flex flex-col gap-1 ' +
              kpiColor(ind.dependency, true)
            }
          >
            <span className="text-[12px] text-slate-600">
              Dependencia de TI
            </span>
            <span className="text-[24px] font-semibold flex items-center gap-1">
              {ind.dependency.toFixed(1)}
              <Database className="w-4 h-4" />
            </span>
          </div>
          <div
            className={
              'rounded-2xl border p-4 shadow-sm flex flex-col gap-1 ' +
              kpiColor(ind.itload, true)
            }
          >
            <span className="text-[12px] text-slate-600">
              Carga Operativa TI
            </span>
            <span className="text-[24px] font-semibold flex items-center gap-1">
              {ind.itload.toFixed(1)}
              <Settings className="w-4 h-4" />
            </span>
          </div>
        </div>

        {/* TABS */}
        <div className="flex flex-wrap gap-2 mb-6 text-[13px]">
          <button className="inline-flex items-center gap-1.5 rounded-xl border bg-white px-3 py-1.5 shadow-sm">
            <BarChart3 className="w-4 h-4" />
            Overview
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-xl border bg-white px-3 py-1.5 shadow-sm">
            <Layers className="w-4 h-4" />
            DAMA
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-xl border bg-white px-3 py-1.5 shadow-sm">
            <TrendingUp className="w-4 h-4" />
            Gaps
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-xl border bg-white px-3 py-1.5 shadow-sm">
            <Shield className="w-4 h-4" />
            Cobertura & Autonomía
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-xl border bg-white px-3 py-1.5 shadow-sm">
            <BookOpen className="w-4 h-4" />
            Heatmap
          </button>
        </div>

        {/* OVERVIEW */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-6">
          <div className="rounded-2xl bg-white border shadow-sm p-4 lg:col-span-2">
            <SectionTitle
              icon={BarChart3}
              title="Madurez por Dimensión"
              subtitle="Escala 1–5 (DAMA agrupado por gerencia)"
            />
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={DIMENSIONS.map(d => ({
                    name: d.label,
                    value: score[d.key],
                  }))}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis domain={[0, 5]} ticks={[1, 2, 3, 4, 5]} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-2xl bg-white border shadow-sm p-4">
            <SectionTitle
              icon={Gauge}
              title="Perfil Radar"
              subtitle="Comparativo multidimensional"
            />
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="dimension" tick={{ fontSize: 10 }} />
                  <PolarRadiusAxis angle={45} domain={[0, 5]} />
                  <Radar
                    name="Madurez"
                    dataKey="valor"
                    stroke="#0ea5e9"
                    fill="#0ea5e9"
                    fillOpacity={0.4}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* DETALLE DAMA */}
        <div className="rounded-2xl bg-white border shadow-sm p-4 mb-6">
          <SectionTitle
            icon={Layers}
            title="Detalle por Dimensión DAMA"
            subtitle="Conecta con la narrativa del diagnóstico (cap. 3 y 4)"
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {DIMENSIONS.map(d => (
              <div
                key={d.key}
                className="rounded-2xl bg-white border border-slate-100 shadow-sm p-4"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[13px] font-semibold">
                    {d.label}
                  </span>
                  <span
                    className={
                      'text-[11px] px-2 py-0.5 rounded-full border ' +
                      kpiColor(score[d.key])
                    }
                  >
                    {score[d.key].toFixed(1)}/5
                  </span>
                </div>
                <p className="text-[12px] text-slate-600 leading-relaxed">
                  Madurez observada para <strong>{d.label}</strong> en la
                  gerencia seleccionada. Usa esta tarjeta para anclar los
                  mensajes tácticos (políticas, linaje, catálogo, integración,
                  etc.).
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* GAPS */}
        <div className="rounded-2xl bg-white border shadow-sm p-4 mb-6">
          <SectionTitle
            icon={TrendingUp}
            title="Brecha vs Objetivo 3.0"
            subtitle="Valores negativos indican madurez por debajo del objetivo"
          />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={gapData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis domain={[-2, 2]} ticks={[-2, -1, 0, 1, 2]} />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="Gap"
                  stroke="#ef4444"
                  strokeWidth={2}
                  dot
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* COBERTURA, AUTONOMÍA, DEPENDENCIA */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
          <div className="rounded-2xl bg-white border shadow-sm p-4">
            <SectionTitle
              icon={Shield}
              title="Cobertura del Diagnóstico"
              subtitle="Representatividad de la información"
            />
            <div className="mt-2 flex items-center gap-2">
              {coveragePill(ind.coverage)}
              <span className="text-[11px] text-slate-500">
                Según alcance de entrevistas y documentación
              </span>
            </div>
            <p className="text-[12px] text-slate-600 mt-3">
              La cobertura mide el alcance y la formalización de la información
              recabada, no el desempeño operativo.
            </p>
          </div>

          <div className="rounded-2xl bg-white border shadow-sm p-4">
            <SectionTitle
              icon={Users}
              title="Autonomía de la Gerencia"
              subtitle="Capacidad de autogestión (1–5)"
            />
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={[{ name: 'Autonomía', value: ind.autonomy }]}>
                  <XAxis dataKey="name" hide />
                  <YAxis domain={[0, 5]} ticks={[1, 2, 3, 4, 5]} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-2xl bg-white border shadow-sm p-4">
            <SectionTitle
              icon={Database}
              title="Dependencia & Carga TI"
              subtitle="(1–5) – menor es mejor"
            />
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={[
                    { name: 'Dependencia', value: ind.dependency },
                    { name: 'Carga TI', value: ind.itload },
                  ]}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 5]} ticks={[1, 2, 3, 4, 5]} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* HEATMAP */}
        <div className="rounded-2xl bg-white border shadow-sm p-4 mb-6">
          <SectionTitle
            icon={BookOpen}
            title="Heatmap – Madurez por Gerencia x Dimensión"
            subtitle="Escala 1–5; más intenso = mayor madurez observada"
          />
          <div className="mt-3 overflow-auto">
            <div className="min-w-[800px]">
              <div
                className="grid"
                style={{
                  gridTemplateColumns: `220px repeat(${DIMENSIONS.length}, 1fr)`,
                }}
              >
                <div className="p-2 bg-slate-100 text-[12px] font-semibold rounded-tl-xl">
                  Gerencia
                </div>
                {DIMENSIONS.map(d => (
                  <div
                    key={d.key}
                    className="p-2 bg-slate-100 text-[12px] font-semibold text-center"
                  >
                    {d.label}
                  </div>
                ))}

                {heatmapData.map((row, idx) => (
                  <React.Fragment key={row.area}>
                    <div
                      className={`p-2 text-[12px] border-b ${
                        idx === heatmapData.length - 1 ? 'rounded-bl-xl' : ''
                      }`}
                    >
                      {row.area}
                    </div>
                    {row.values.map((v, j) => (
                      <div
                        key={j}
                        className="p-2 text-center border-b last:border-r-0"
                      >
                        <span
                          className={
                            'inline-flex min-w-[40px] justify-center px-2 py-1 rounded-xl border text-[11px] font-medium ' +
                            heatColor(v.value)
                          }
                        >
                          {v.value.toFixed(1)}
                        </span>
                      </div>
                    ))}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* FOOTER */}
        <div className="mt-4 text-[11px] text-slate-500 flex items-start gap-2">
          <Info className="w-3 h-3 mt-0.5" />
          <p>
            Este panel es una representación visual del diagnóstico ejecutivo.
            Los valores provienen del análisis As-Is y pueden afinarse con los
            números finales validados con el cliente.
          </p>
        </div>
      </div>
    </div>
  )
}
